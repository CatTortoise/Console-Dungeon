﻿//Basic C# for Games
//Dor Ben-Dor
//Final Project 
//Yshai flising
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Dungeon
{
    class Program
    {
        static void Main(string[] args)
        {

            GameManager.StartConsoleDungeon() ;

        }

    }
}